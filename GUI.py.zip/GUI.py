import tkinter as tk
from tkinter import Menu, messagebox

# Function to add a new task
def add_task():
    task = entry.get().strip()  # Remove leading/trailing spaces
    if task == "":
        messagebox.showwarning("Input Error", "Task cannot be empty.")
    else:
        listbox.insert(tk.END, task)
        entry.delete(0, tk.END)

# Function to delete a task (right-click)
def delete_task(event):
    try:
        task_index = listbox.curselection()
        if task_index:
            listbox.delete(task_index)
        else:
            messagebox.showwarning("Selection Error", "Please select a task to delete.")
    except Exception as e:
        print(f"Error: {e}")

# Function to exit the program
def exit_program():
    root.quit()

# Setup the main window
root = tk.Tk()
root.title("bell-ToDo")  # Change the window title to your last name and ToDo
root.geometry("400x400")

# Set up the menu bar with complementary colors (blue and orange)
menu_bar = Menu(root)
root.config(menu=menu_bar)

# File menu with blue background and orange text for the file menu
file_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)

# Add the Exit option with complementary colors
file_menu.add_command(
    label="Exit",
    command=exit_program,
    activebackground="pink",   # Orange background when the item is selected
    activeforeground="green",     # Blue text when the item is selected
    background="blue",          # Blue background
    foreground="orange"         # Orange text
)

# Task listbox with a scrollbar
listbox_frame = tk.Frame(root)
listbox_frame.pack(pady=20)

scrollbar = tk.Scrollbar(listbox_frame)
listbox = tk.Listbox(listbox_frame, selectmode=tk.SINGLE, width=40, height=10, yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)

# Label for instructions
label = tk.Label(root, text="Right-click to delete a task.", font=("Arial", 12))
label.pack(pady=10)

# Add task entry field and button
entry = tk.Entry(root, width=30)
entry.pack(pady=10)

add_button = tk.Button(root, text="Add Task", width=20, command=add_task)
add_button.pack(pady=10)

# Pack the listbox and scrollbar
listbox.pack(side=tk.LEFT)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Bind the right-click to the delete function
listbox.bind("<Button-3>", delete_task)

# Run the application
root.mainloop()
