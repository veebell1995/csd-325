def calculate_sum(numbers):
    total = 0
    for number in numbers:
        total += number
    return total / len(numbers)  # This line introduces a bug when the list is empty

def main():
    numbers = []
    result = calculate_sum(numbers)
    print("The sum of the numbers is:", result)

if __name__ == "__main__":
    main()
