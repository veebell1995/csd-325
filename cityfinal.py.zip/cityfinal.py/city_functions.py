# city_functions.py

# Define the function city_country with optional language and population parameters
def city_country(city, country, population=None, language=None):
    if population and language:
        return f"{city}, {country} - population {population}, {language}"
    elif population:
        return f"{city}, {country} - population {population}"
    elif language:
        return f"{city}, {country} - {language}"
    else:
        return f"{city}, {country}"

# Call the function three times with different values
print(city_country("Santiago", "Chile", 5000000, "Spanish"))
print(city_country("Paris", "France", 2206488, "French"))
print(city_country("Tokyo", "Japan"))



