# test_cities.py

import unittest
from city_functions import city_country


class TestCityCountry(unittest.TestCase):
    # Define the test method
    def test_city_country(self):
        # Call the function with specific inputs
        result = city_country("Santiago", "Chile")

        # Check if the result is as expected
        self.assertEqual(result, "Santiago, Chile")

        # Additional tests with other city-country pairs
        result = city_country("Paris", "France")
        self.assertEqual(result, "Paris, France")

        result = city_country("Tokyo", "Japan")
        self.assertEqual(result, "Tokyo, Japan")


# Run the tests
if __name__ == "__main__":
    unittest.main()
